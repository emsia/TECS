stopwords_en = tolower( scan("stopwords_english.txt", what="character", sep = " ", quiet = TRUE) )
