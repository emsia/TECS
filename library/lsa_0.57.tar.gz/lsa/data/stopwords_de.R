stopwords_de = tolower( scan("stopwords_german.txt", what="character", sep = " ", quiet = TRUE) )
